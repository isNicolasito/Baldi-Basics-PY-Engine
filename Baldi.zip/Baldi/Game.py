import math
import os
import sys
from collections import deque

import pygame

try:
    import numpy as np
except ImportError:
    np = None


# ==========================================================
# Baldi-inspired first-person prototype for pygame
# - Console menu + settings
# - Raycast 3D view
# - Connected school map with rooms and hallways
# - Notebooks to collect
# - Simple enemy AI that chases the player
# - Texture folder support with graceful fallback
# ==========================================================

TITLE = "Baldi Basics Inspired Prototype"
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TEXTURE_DIR = os.path.join(BASE_DIR, "assets", "textures")

DEFAULT_SETTINGS = {
    "width": 960,
    "height": 540,
    "fov": 66,
    "mouse_sensitivity": 0.25,
    "difficulty": "normal",
    # Fixed gameplay values
    "move_speed": 3.4,
    "run_speed": 5.0,
    "enemy_speed": 1.8,
    "target_notebooks": 7,
}


# ==========================================================
# Console menu / settings
# ==========================================================

def console_clear():
    os.system("cls" if os.name == "nt" else "clear")


def ask_int(prompt, default, minimum=None, maximum=None):
    while True:
        raw = input(f"{prompt} [{default}]: ").strip()
        if not raw:
            value = default
        else:
            try:
                value = int(raw)
            except ValueError:
                print("Please enter a number.")
                continue
        if minimum is not None and value < minimum:
            print(f"Minimum: {minimum}")
            continue
        if maximum is not None and value > maximum:
            print(f"Maximum: {maximum}")
            continue
        return value


def ask_float(prompt, default, minimum=None, maximum=None):
    while True:
        raw = input(f"{prompt} [{default}]: ").strip()
        if not raw:
            value = default
        else:
            try:
                value = float(raw)
            except ValueError:
                print("Please enter a valid number.")
                continue
        if minimum is not None and value < minimum:
            print(f"Minimum: {minimum}")
            continue
        if maximum is not None and value > maximum:
            print(f"Maximum: {maximum}")
            continue
        return value


def ask_menu():
    settings = dict(DEFAULT_SETTINGS)
    while True:
        console_clear()
        print("=== BALDI BASICS IN PYTHON / PYGAME ===")
        print("1) Play")
        print("2) Settings")
        print("3) Exit")
        choice = input("> ").strip()

        if choice == "1":
            return settings

        if choice == "2":
            console_clear()
            print("=== SETTINGS ===")
            settings["width"] = ask_int("Width", settings["width"], 640, 1920)
            settings["height"] = ask_int("Height", settings["height"], 360, 1080)
            settings["fov"] = ask_int("FOV", settings["fov"], 40, 90)
            settings["mouse_sensitivity"] = ask_float(
                "Mouse sensitivity", settings["mouse_sensitivity"], 0.005, 2.0
            )

            diff = input("Difficulty (easy/normal/hard) [normal]: ").strip().lower()
            if diff in ("easy", "normal", "hard"):
                settings["difficulty"] = diff

            input("Press Enter to go back...")
        elif choice == "3":
            sys.exit(0)
        else:
            print("Invalid option.")
            input("Press Enter...")


# ==========================================================
# Map generation
# ==========================================================

# 0 = empty, 1 = wall, 2 = notebook marker, 3 = spawn, 4 = exit, 5 = enemy spawn
MAP_W = 39
MAP_H = 39


def make_grid(w, h, fill=1):
    return [[fill for _ in range(w)] for _ in range(h)]


def carve_room(grid, x, y, w, h, tile=0):
    for yy in range(y, y + h):
        for xx in range(x, x + w):
            if 0 <= xx < len(grid[0]) and 0 <= yy < len(grid):
                grid[yy][xx] = tile


def carve_hall_h(grid, x1, x2, y, tile=0):
    if x1 > x2:
        x1, x2 = x2, x1
    for x in range(x1, x2 + 1):
        if 0 <= x < len(grid[0]) and 0 <= y < len(grid):
            grid[y][x] = tile


def carve_hall_v(grid, y1, y2, x, tile=0):
    if y1 > y2:
        y1, y2 = y2, y1
    for y in range(y1, y2 + 1):
        if 0 <= x < len(grid[0]) and 0 <= y < len(grid):
            grid[y][x] = tile


def generate_school_map():
    grid = make_grid(MAP_W, MAP_H, fill=1)

    # Main hallways
    carve_hall_h(grid, 2, MAP_W - 3, 6)
    carve_hall_h(grid, 2, MAP_W - 3, 18)
    carve_hall_h(grid, 2, MAP_W - 3, 30)

    carve_hall_v(grid, 2, MAP_H - 3, 6)
    carve_hall_v(grid, 2, MAP_H - 3, 18)
    carve_hall_v(grid, 2, MAP_H - 3, 30)

    # Rooms
    rooms = [
        (1, 1, 4, 4),
        (8, 1, 8, 4),
        (20, 1, 8, 4),
        (32, 1, 5, 4),
        (1, 8, 4, 8),
        (8, 8, 8, 8),
        (20, 8, 8, 8),
        (32, 8, 5, 8),
        (1, 20, 4, 8),
        (8, 20, 8, 8),
        (20, 20, 8, 8),
        (32, 20, 5, 8),
        (1, 32, 4, 5),
        (8, 32, 8, 5),
        (20, 32, 8, 5),
        (32, 32, 5, 5),
    ]
    for x, y, w, h in rooms:
        carve_room(grid, x, y, w, h)

    # Doorways so every area connects to hallways.
    connectors = [
        (5, 3), (12, 5), (24, 5), (34, 5),
        (5, 11), (12, 18), (24, 18), (34, 18),
        (5, 23), (12, 30), (24, 30), (34, 30),
        (5, 35), (12, 31), (24, 31), (34, 31),
    ]
    for cx, cy in connectors:
        if 0 <= cx < MAP_W and 0 <= cy < MAP_H:
            grid[cy][cx] = 0

    # Spawn, exit, enemy spawn
    grid[6][3] = 3
    grid[30][35] = 4
    grid[18][18] = 5

    # Open a little space around Baldi so he never spawns trapped.
    for oy in (-1, 0, 1):
        for ox in (-1, 0, 1):
            xx, yy = 18 + ox, 18 + oy
            if 0 <= xx < MAP_W and 0 <= yy < MAP_H and (xx, yy) != (18, 18):
                grid[yy][xx] = 0

    return grid


def get_spawn_and_points(grid):
    spawn = (3.5, 6.5)
    enemy_spawn = (18.5, 18.5)
    exit_pos = (35.5, 30.5)
    notebooks = []

    for y, row in enumerate(grid):
        for x, cell in enumerate(row):
            if cell == 3:
                spawn = (x + 0.5, y + 0.5)
            elif cell == 4:
                exit_pos = (x + 0.5, y + 0.5)
            elif cell == 5:
                enemy_spawn = (x + 0.5, y + 0.5)

    notebook_cells = [(2, 2), (10, 2), (22, 2), (33, 2), (10, 10), (22, 10), (33, 10), (10, 22)]
    for x, y in notebook_cells:
        if 0 <= x < MAP_W and 0 <= y < MAP_H and grid[y][x] == 0:
            notebooks.append((x + 0.5, y + 0.5))

    return spawn, enemy_spawn, exit_pos, notebooks


# ==========================================================
# Texture loading
# ==========================================================

def clamp(value, a, b):
    return max(a, min(b, value))


def make_placeholder_texture(size, fallback_color):
    surf = pygame.Surface((size, size), pygame.SRCALPHA)
    surf.fill((*fallback_color, 255))

    dark = (
        max(0, fallback_color[0] - 20),
        max(0, fallback_color[1] - 20),
        max(0, fallback_color[2] - 20),
    )
    light = (
        min(255, fallback_color[0] + 20),
        min(255, fallback_color[1] + 20),
        min(255, fallback_color[2] + 20),
    )

    for y in range(0, size, 8):
        pygame.draw.line(surf, dark, (0, y), (size, y), 1)
    for x in range(0, size, 8):
        pygame.draw.line(surf, light, (x, 0), (x, size), 1)

    return surf.convert_alpha()


def load_texture(name, fallback_color, size=64):
    path = os.path.join(TEXTURE_DIR, name)
    if os.path.exists(path):
        img = pygame.image.load(path).convert_alpha()
        if img.get_width() != size or img.get_height() != size:
            img = pygame.transform.smoothscale(img, (size, size))

        # If Baldi's image is basically invisible, use a solid fallback.
        if name.lower() == "baldi.png":
            mask = pygame.mask.from_surface(img)
            if mask.count() < (size * size) // 20:
                return make_placeholder_texture(size, fallback_color)

        return img

    return make_placeholder_texture(size, fallback_color)


# ==========================================================
# Pathfinding / AI
# ==========================================================

def passable(grid, x, y):
    if not (0 <= x < MAP_W and 0 <= y < MAP_H):
        return False
    return grid[y][x] != 1


def bfs_next_step(grid, start, goal):
    sx, sy = start
    gx, gy = goal
    s = (int(sx), int(sy))
    g = (int(gx), int(gy))

    if s == g:
        return None

    q = deque([s])
    came = {s: None}
    dirs = [(1, 0), (-1, 0), (0, 1), (0, -1)]

    while q:
        cur = q.popleft()
        if cur == g:
            break
        cx, cy = cur
        for dx, dy in dirs:
            nx, ny = cx + dx, cy + dy
            nxt = (nx, ny)
            if nxt not in came and passable(grid, nx, ny):
                came[nxt] = cur
                q.append(nxt)

    if g not in came:
        return None

    step = g
    while came.get(step) != s and came.get(step) is not None:
        step = came[step]
    return step


# ==========================================================
# Game
# ==========================================================

class Game:
    def __init__(self, settings):
        pygame.init()
        pygame.display.set_caption(TITLE)

        self.settings = settings
        self.width = settings["width"]
        self.height = settings["height"]

        self.screen = pygame.display.set_mode((self.width, self.height))
        self.clock = pygame.time.Clock()

        self.font = pygame.font.SysFont("arial", 18)
        self.big_font = pygame.font.SysFont("arial", 34, bold=True)

        self.fov = math.radians(settings["fov"])
        self.mouse_sens = settings["mouse_sensitivity"]
        self.move_speed = settings["move_speed"]
        self.run_speed = settings["run_speed"]
        self.enemy_speed = settings["enemy_speed"]
        self.target_notebooks = settings["target_notebooks"]
        self.difficulty = settings["difficulty"]

        # Lower internal render resolution for better performance.
        self.rw = max(240, self.width // 3)
        self.rh = max(160, self.height // 3)
        self.render_surface = pygame.Surface((self.rw, self.rh)).convert()
        self.canvas = np.empty((self.rw, self.rh, 3), dtype=np.uint8) if np is not None else None
        self.use_numpy = np is not None

        self.num_rays = self.rw
        self.delta_angle = self.fov / self.num_rays
        self.dist = self.num_rays / (2 * math.tan(self.fov / 2))
        self.scale = self.rw / self.num_rays

        self.grid = generate_school_map()
        self.spawn, self.enemy_spawn, self.exit_pos, self.notebook_positions = get_spawn_and_points(self.grid)

        self.wall_tex = load_texture("wall.png", (140, 140, 160))
        self.floor_tex = load_texture("floor.png", (90, 90, 95))
        self.ceiling_tex = load_texture("ceiling.png", (110, 115, 130))
        self.baldi_tex = load_texture("baldi.png", (235, 225, 40))
        self.notebook_tex = load_texture("notebook.png", (240, 240, 255))
        self.exit_tex = load_texture("exit.png", (70, 170, 90))

        if self.use_numpy:
            self.floor_arr = pygame.surfarray.array3d(self.floor_tex)
            self.ceiling_arr = pygame.surfarray.array3d(self.ceiling_tex)
            self.xs = np.arange(self.rw, dtype=np.float32)

        self.reset()

        pygame.event.set_grab(True)
        pygame.mouse.set_visible(False)
        self.center_x = self.width // 2
        self.center_y = self.height // 2
        pygame.mouse.set_pos((self.center_x, self.center_y))

        self.flash = 0.0

    def reset(self):
        self.player_x, self.player_y = self.spawn
        self.player_yaw = 0.0
        self.pitch = 0.0

        self.notebooks_collected = 0
        self.game_over = False
        self.win = False
        self.escape_open = False

        self.baldi_x, self.baldi_y = self.enemy_spawn
        self.enemy_speed_current = self.settings["enemy_speed"]
        self.enemy_repath_timer = 0.0
        self.enemy_path_step = None

        self.notebooks = [list(pos) for pos in self.notebook_positions]
        self.collect_radius = 0.55
        self.jumpscare_timer = 0.0
        self.time_alive = 0.0

    # --------------------- Utility ---------------------

    def is_wall(self, x, y):
        gx, gy = int(x), int(y)
        if not (0 <= gx < MAP_W and 0 <= gy < MAP_H):
            return True
        return self.grid[gy][gx] == 1

    def can_move_to(self, x, y, r=0.20):
        checks = [
            (x - r, y - r),
            (x + r, y - r),
            (x - r, y + r),
            (x + r, y + r),
        ]
        return all(not self.is_wall(cx, cy) for cx, cy in checks)

    def cast_rays(self):
        rays = []
        for ray in range(self.num_rays):
            ray_angle = self.player_yaw - self.fov / 2 + self.delta_angle * ray
            sin_r = math.sin(ray_angle)
            cos_r = math.cos(ray_angle)

            map_x = int(self.player_x)
            map_y = int(self.player_y)

            delta_dist_x = abs(1 / cos_r) if cos_r != 0 else 1e9
            delta_dist_y = abs(1 / sin_r) if sin_r != 0 else 1e9

            if cos_r < 0:
                step_x = -1
                side_dist_x = (self.player_x - map_x) * delta_dist_x
            else:
                step_x = 1
                side_dist_x = (map_x + 1.0 - self.player_x) * delta_dist_x

            if sin_r < 0:
                step_y = -1
                side_dist_y = (self.player_y - map_y) * delta_dist_y
            else:
                step_y = 1
                side_dist_y = (map_y + 1.0 - self.player_y) * delta_dist_y

            hit = False
            side = 0
            cell = 1

            while not hit:
                if side_dist_x < side_dist_y:
                    side_dist_x += delta_dist_x
                    map_x += step_x
                    side = 0
                else:
                    side_dist_y += delta_dist_y
                    map_y += step_y
                    side = 1

                if not (0 <= map_x < MAP_W and 0 <= map_y < MAP_H):
                    hit = True
                    cell = 1
                    break

                cell = self.grid[map_y][map_x]
                if cell == 1:
                    hit = True

            if side == 0:
                perp_dist = (map_x - self.player_x + (1 - step_x) / 2) / (cos_r if cos_r != 0 else 1e-9)
            else:
                perp_dist = (map_y - self.player_y + (1 - step_y) / 2) / (sin_r if sin_r != 0 else 1e-9)

            perp_dist = max(perp_dist, 0.0001)
            rays.append((ray, perp_dist, side, cell, ray_angle))

        return rays

    # --------------------- Background ---------------------

    def draw_floor_and_ceiling(self, horizon):
        if not self.use_numpy:
            self.render_surface.fill((55, 55, 65))
            pygame.draw.rect(self.render_surface, (35, 32, 30), (0, horizon, self.rw, self.rh - horizon))
            return

        canvas = self.canvas

        dir_x = math.cos(self.player_yaw)
        dir_y = math.sin(self.player_yaw)
        plane_len = math.tan(self.fov / 2)
        plane_x = -math.sin(self.player_yaw) * plane_len
        plane_y = math.cos(self.player_yaw) * plane_len

        ray0_x = dir_x - plane_x
        ray0_y = dir_y - plane_y
        ray1_x = dir_x + plane_x
        ray1_y = dir_y + plane_y

        tex_floor = self.floor_arr
        tex_ceil = self.ceiling_arr
        tex_w = tex_floor.shape[0]
        tex_h = tex_floor.shape[1]

        for y in range(self.rh):
            if y == horizon:
                continue

            p = abs(y - horizon)
            row_dist = (0.5 * self.rh) / max(p, 1)

            step_x = row_dist * (ray1_x - ray0_x) / self.rw
            step_y = row_dist * (ray1_y - ray0_y) / self.rw

            world_x = self.player_x + row_dist * ray0_x + self.xs * step_x
            world_y = self.player_y + row_dist * ray0_y + self.xs * step_y

            fx = np.mod(world_x, 1.0)
            fy = np.mod(world_y, 1.0)

            tx = (fx * (tex_w - 1)).astype(np.int32)
            ty = (fy * (tex_h - 1)).astype(np.int32)

            if y < horizon:
                canvas[:, y, :] = tex_ceil[tx, ty]
            else:
                canvas[:, y, :] = tex_floor[tx, ty]

        pygame.surfarray.blit_array(self.render_surface, canvas)

    # --------------------- Drawing ---------------------

    def draw_world(self):
        horizon = int(clamp(self.rh // 2 + self.pitch, 0, self.rh - 1))
        self.draw_floor_and_ceiling(horizon)

        rays = self.cast_rays()
        z_buffer = [0.0] * self.num_rays

        # Walls
        for ray, dist, side, cell, ray_angle in rays:
            z_buffer[ray] = dist
            wall_h = int(self.dist / dist)
            wall_h = max(1, min(self.rh * 2, wall_h))

            start_y = horizon - wall_h // 2

            if side == 0:
                hit = self.player_y + dist * math.sin(ray_angle)
            else:
                hit = self.player_x + dist * math.cos(ray_angle)

            tex_x = int((hit - math.floor(hit)) * self.wall_tex.get_width())
            tex_x = clamp(tex_x, 0, self.wall_tex.get_width() - 1)

            column = self.wall_tex.subsurface(tex_x, 0, 1, self.wall_tex.get_height())
            column = pygame.transform.scale(column, (max(1, int(self.scale) + 1), wall_h))

            if side == 1:
                shade = pygame.Surface(column.get_size()).convert_alpha()
                shade.fill((0, 0, 0, 70))
                column.blit(shade, (0, 0), special_flags=pygame.BLEND_RGBA_SUB)

            self.render_surface.blit(column, (int(ray * self.scale), start_y))

        # Sprites
        sprites = []
        for nx, ny in self.notebooks:
            sprites.append((nx, ny, "notebook"))
        sprites.append((self.exit_pos[0], self.exit_pos[1], "exit"))
        sprites.append((self.baldi_x, self.baldi_y, "baldi"))

        sprites.sort(key=lambda s: (s[0] - self.player_x) ** 2 + (s[1] - self.player_y) ** 2, reverse=True)

        for sx, sy, kind in sprites:
            dx = sx - self.player_x
            dy = sy - self.player_y
            distance = math.hypot(dx, dy)
            if distance < 0.2:
                continue

            angle_to_sprite = math.atan2(dy, dx)
            rel = (angle_to_sprite - self.player_yaw + math.pi) % (2 * math.pi) - math.pi
            if abs(rel) > self.fov / 2 + 0.2:
                continue

            sprite_screen_x = int((rel + self.fov / 2) / self.fov * self.rw)
            sprite_h = max(1, int(self.dist / distance))
            sprite_w = sprite_h
            top = horizon - sprite_h // 2
            left = sprite_screen_x - sprite_w // 2

            if kind == "notebook":
                tex = self.notebook_tex
            elif kind == "exit":
                tex = self.exit_tex
            else:
                tex = self.baldi_tex

            tex = pygame.transform.scale(tex, (sprite_w, sprite_h))

            for x in range(max(0, left), min(self.rw, left + sprite_w)):
                ray_idx = int(x / self.scale)
                if 0 <= ray_idx < len(z_buffer) and distance < z_buffer[ray_idx] + 0.25:
                    src_x = int((x - left) / sprite_w * tex.get_width())
                    self.render_surface.blit(tex, (x, top), area=pygame.Rect(src_x, 0, 1, tex.get_height()))

        pygame.transform.scale(self.render_surface, (self.width, self.height), self.screen)
        self.draw_hud()

    def draw_hud(self):
        pygame.draw.line(self.screen, (255, 255, 255), (self.width // 2 - 8, self.height // 2), (self.width // 2 + 8, self.height // 2), 2)
        pygame.draw.line(self.screen, (255, 255, 255), (self.width // 2, self.height // 2 - 8), (self.width // 2, self.height // 2 + 8), 2)

        panel = pygame.Surface((self.width, 34), pygame.SRCALPHA)
        panel.fill((0, 0, 0, 110))
        self.screen.blit(panel, (0, 0))

        txt = self.font.render(
            f"Notebooks: {self.notebooks_collected}/{self.target_notebooks}   Time: {self.time_alive:0.1f}s   Difficulty: {self.difficulty}",
            True,
            (255, 255, 255),
        )
        self.screen.blit(txt, (12, 8))

        for nx, ny in self.notebooks:
            if math.hypot(nx - self.player_x, ny - self.player_y) < 0.75:
                prompt = self.big_font.render("E - Pick up notebook", True, (255, 255, 255))
                self.screen.blit(prompt, (self.width // 2 - prompt.get_width() // 2, self.height - 90))
                break

        if math.hypot(self.exit_pos[0] - self.player_x, self.exit_pos[1] - self.player_y) < 1.0:
            if self.escape_open:
                prompt = self.big_font.render("EXIT OPEN - PRESS E", True, (255, 255, 255))
            else:
                prompt = self.big_font.render("EXIT LOCKED", True, (255, 255, 255))
            self.screen.blit(prompt, (self.width // 2 - prompt.get_width() // 2, self.height - 90))

    # --------------------- Gameplay ---------------------

    def collect_notebook(self):
        for i, (nx, ny) in enumerate(self.notebooks):
            if math.hypot(nx - self.player_x, ny - self.player_y) < self.collect_radius:
                self.notebooks.pop(i)
                self.notebooks_collected += 1
                self.flash = 0.25
                self.enemy_speed_current += 0.08
                return True
        return False

    def update_enemy(self, dt):
        self.enemy_repath_timer -= dt
        if self.enemy_repath_timer <= 0:
            self.enemy_repath_timer = 0.30
            self.enemy_path_step = bfs_next_step(
                self.grid,
                (self.baldi_x, self.baldi_y),
                (self.player_x, self.player_y),
            )

        if self.enemy_path_step is not None:
            target = (self.enemy_path_step[0] + 0.5, self.enemy_path_step[1] + 0.5)
        else:
            target = (self.player_x, self.player_y)

        dx = target[0] - self.baldi_x
        dy = target[1] - self.baldi_y
        dist = math.hypot(dx, dy)

        if dist > 0.01:
            speed = self.enemy_speed_current
            if self.difficulty == "hard":
                speed *= 1.18
            elif self.difficulty == "easy":
                speed *= 0.85

            step = min(dist, speed * dt)
            nx = self.baldi_x + dx / dist * step
            ny = self.baldi_y + dy / dist * step

            if self.can_move_to(nx, self.baldi_y, r=0.14):
                self.baldi_x = nx
            if self.can_move_to(self.baldi_x, ny, r=0.14):
                self.baldi_y = ny

        if math.hypot(self.baldi_x - self.player_x, self.baldi_y - self.player_y) < 0.55:
            self.game_over = True
            self.jumpscare_timer = 1.5

    def update_player(self, dt, keys):
        speed = self.move_speed if self.difficulty != "hard" else self.move_speed * 1.08
        if keys[pygame.K_LSHIFT] or keys[pygame.K_RSHIFT]:
            speed = self.run_speed

        sin_a = math.sin(self.player_yaw)
        cos_a = math.cos(self.player_yaw)

        dx = dy = 0.0
        if keys[pygame.K_w]:
            dx += cos_a * speed * dt
            dy += sin_a * speed * dt
        if keys[pygame.K_s]:
            dx -= cos_a * speed * dt
            dy -= sin_a * speed * dt
        if keys[pygame.K_a]:
            dx += math.cos(self.player_yaw - math.pi / 2) * speed * dt
            dy += math.sin(self.player_yaw - math.pi / 2) * speed * dt
        if keys[pygame.K_d]:
            dx += math.cos(self.player_yaw + math.pi / 2) * speed * dt
            dy += math.sin(self.player_yaw + math.pi / 2) * speed * dt

        nx = self.player_x + dx
        ny = self.player_y + dy

        if self.can_move_to(nx, self.player_y):
            self.player_x = nx
        if self.can_move_to(self.player_x, ny):
            self.player_y = ny

        mouse_x, mouse_y = pygame.mouse.get_pos()
        mx = mouse_x - self.center_x
        my = mouse_y - self.center_y
        pygame.mouse.set_pos((self.center_x, self.center_y))

        turn = mx * self.mouse_sens * 0.012
        if keys[pygame.K_LEFT]:
            turn -= 1.8 * dt
        if keys[pygame.K_RIGHT]:
            turn += 1.8 * dt

        # Full 360-degree yaw.
        self.player_yaw = (self.player_yaw + turn) % math.tau

        # Vertical look.
        self.pitch = clamp(
            self.pitch - my * self.mouse_sens * 1.2,
            -self.rh * 0.35,
            self.rh * 0.35,
        )

    def check_progress(self):
        if self.notebooks_collected >= self.target_notebooks:
            self.escape_open = True
        if self.escape_open and math.hypot(self.exit_pos[0] - self.player_x, self.exit_pos[1] - self.player_y) < 0.9:
            self.win = True

    def draw_overlay_messages(self):
        if self.flash > 0:
            overlay = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
            overlay.fill((255, 255, 255, int(180 * self.flash)))
            self.screen.blit(overlay, (0, 0))

        if self.game_over:
            overlay = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
            overlay.fill((120, 0, 0, 170))
            self.screen.blit(overlay, (0, 0))
            t = self.big_font.render("BALDI GOT YOU", True, (255, 255, 255))
            self.screen.blit(t, (self.width // 2 - t.get_width() // 2, self.height // 2 - 50))
            t2 = self.font.render("Press R to restart or ESC to quit", True, (255, 255, 255))
            self.screen.blit(t2, (self.width // 2 - t2.get_width() // 2, self.height // 2 + 5))

        if self.win:
            overlay = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
            overlay.fill((0, 80, 0, 160))
            self.screen.blit(overlay, (0, 0))
            t = self.big_font.render("YOU ESCAPED", True, (255, 255, 255))
            self.screen.blit(t, (self.width // 2 - t.get_width() // 2, self.height // 2 - 50))
            t2 = self.font.render("Press R to play again or ESC to quit", True, (255, 255, 255))
            self.screen.blit(t2, (self.width // 2 - t2.get_width() // 2, self.height // 2 + 5))

    # --------------------- Main loop ---------------------

    def run(self):
        while True:
            dt = self.clock.tick(60) / 1000.0
            self.time_alive += dt
            self.flash = max(0.0, self.flash - dt * 2.5)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    return

                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        return

                    if event.key == pygame.K_r and (self.game_over or self.win):
                        self.reset()

                    if event.key == pygame.K_e and not (self.game_over or self.win):
                        got = self.collect_notebook()
                        if not got and self.escape_open and math.hypot(self.exit_pos[0] - self.player_x, self.exit_pos[1] - self.player_y) < 1.0:
                            self.win = True

            keys = pygame.key.get_pressed()

            if not (self.game_over or self.win):
                self.update_player(dt, keys)
                self.update_enemy(dt)
                self.check_progress()

            self.draw_world()
            self.draw_overlay_messages()
            pygame.display.flip()


# ==========================================================
# Entry point
# ==========================================================

def main():
    settings = ask_menu()
    game = Game(settings)
    try:
        game.run()
    finally:
        pygame.quit()


if __name__ == "__main__":
    main()